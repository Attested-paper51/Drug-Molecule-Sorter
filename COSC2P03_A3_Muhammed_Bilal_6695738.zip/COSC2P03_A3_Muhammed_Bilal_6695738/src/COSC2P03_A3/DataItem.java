package COSC2P03_A3;

public class DataItem
{
    // Instance Variables
    public String smiles, fragments;
    public int n_fragments, C, F, N, O, Other, SINGLE, DOUBLE, TRIPLE, Tri, Quad, Pent, Hex;
    public float logP, mr, qed, SAS;
    public int sumRank;

    // Constructor
    public DataItem()
    {

    }
}
